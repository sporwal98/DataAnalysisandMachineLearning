The folder here is named so as I took the code from that workshop and modified it. When I try to change the name of the folder, 'make' stops working
